(function ($) {
  "use strict";

  // Initialize WOW.js for animation effects
  new WOW().init();

  // Navbar cart toggle functionality
  $(".cart_link > a").on("click", function () {
    $(".mini_cart").addClass("active"); // Opens the mini cart
  });

  $(".mini_cart_close > a").on("click", function () {
    $(".mini_cart").removeClass("active"); // Closes the mini cart
  });

  // Sticky navbar functionality
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop(); // Get current scroll position
    if (scroll < 100) {
      $(".sticky-header").removeClass("sticky"); 
    } else {
      $(".sticky-header").addClass("sticky"); // Add sticky class if scrolled more than 100px
    }
  });

  
  function dataBackgroundImage() {
    $("[data-bgimg]").each(function () {
      var bgImgUrl = $(this).data("bgimg"); // Get image URL from data attribute
      $(this).css({
        "background-image": "url(" + bgImgUrl + ")", // Apply background image
      });
    });
  }

  // Run the background image function when the page loads
  $(window).on("load", function () {
    dataBackgroundImage();
  });

  // Carousel slider for the slider section
  $(".slider_area").owlCarousel({
    animateOut: "fadeOut", 
    autoplay: true, // Enable autoplay
    loop: true, // Enable infinite loop
    nav: false, 
    autoplayTimeout: 6000, 
    items: 1, // 
    dots: true, // Enable navigation dots
  });

  // Product carousel with responsive settings
  $(".product_column3").slick({
    centerMode: true, // Enable center mode
    centerPadding: "0", 
    slidesToShow: 5, 
    arrows: true, // Enable navigation arrows
    rows: 2, // Show 2 rows of products
    prevArrow: '<button class="prev_arrow"><i class="ion-chevron-left"></i></button>', 
    nextArrow: '<button class="next_arrow"><i class="ion-chevron-right"></i></button>', 
    responsive: [
      {
        breakpoint: 400, // For screen widths less than 400px
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768, // For screen widths less than 768px
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
        },
      },
      {
        breakpoint: 992, // For screen widths less than 992px
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
        },
      },
      {
        breakpoint: 1200, // For screen widths less than 1200px
        settings: {
          slidesToShow: 4,
          slidesToScroll: 4,
        },
      },
    ],
  });
})(jQuery);

$('[data-toggle="tooltip"]').tooltip();

//tooltip active
$(".action_links ul li a, .quick_button a").tooltip({
  animated: "fade",
  placement: "top",
  container: "body",
});

//product row activation responsive
$(".product_row1").slick({
  centerMode: true,
  centerPadding: "0",
  slidesToShow: 5,
  arrows: true,
  prevArrow:
    '<button class="prev_arrow"><i class="ion-chevron-left"></i></button>',
  nextArrow:
    '<button class="next_arrow"><i class="ion-chevron-right"></i></button>',
  responsive: [
    {
      breakpoints: 400,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
    {
      breakpoints: 768,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
      },
    },
    {
      breakpoints: 992,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
      },
    },
    {
      breakpoints: 1200,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 4,
      },
    },
  ],
});

// blog section
$(".blog_column3").owlCarousel({
  autoplay: true,
  loop: true,
  nav: true,
  autoplayTimeout: 5000,
  items: 3,
    dots: false,
    margin: 30,
    navText: [
      '<i class="ion-chevron-left"></i>',
      '<i class="ion-chevron-right"></i>',
    ],
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
      },
      768: {
        items: 2,
      },
      992: {
        items: 3,
      },
    },
  });

   //navactive responsive
$(".product_navactive").owlCarousel({
  autoplay: false,
  loop: true,
  nav: true,
  items: 4,
  dots: false,
  navText: [
    '<i class="ion-chevron-left arrow-left"></i>',
    '<i class="ion-chevron-right arrow-right"></i>',
  ],
  responsiveClass: true,
  responsive: {
    0: {
      items: 1,
    },
    250: {
      items: 2,
    },
    480: {
      items: 3,
    },
    768: {
      items: 4,
    },
  },
});

$(".modal").on("shown.bs.modal", function (e) {
  $(".product_navactive").trigger('refresh.owl.carousel');  // Use 'trigger' for better compatibility
});

$(".product_navactive a").on("click", function (e) {
  e.preventDefault();
  var $href = $(this).attr("href");
  $(".product_navactive a").removeClass("active");
  $(this).addClass("active");
  $(".product-details-large .tab-pane").removeClass("active show");
  $(".product-details-large " + $href).addClass("active show");
});
